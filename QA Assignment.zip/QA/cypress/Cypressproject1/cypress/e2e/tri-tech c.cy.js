it('Google search',()=>{
    cy.visit('localhost/tritech-crm')
    cy.get('[type="text"]').type('admin')
    cy.get('[type="password"]').type('admin')
    cy.get('.btn-login').click()

    cy.get(':nth-child(6) > a').click()
    cy.get('.btn-main > .fas').click()
    cy.get(':nth-child(1) > :nth-child(2) > input').type('Nipuni')
    cy.get(':nth-child(2) > :nth-child(2) > input').type('0713226969')
    cy.get(':nth-child(3) > :nth-child(2) > input').type('nipuninawanjana066@gmail.com')
    cy.get('select').select('Female')
    cy.get(':nth-child(5) > :nth-child(2) > input').type('2024-12-31')
    cy.get(':nth-child(6) > :nth-child(2) > input').type('Rathnapura')
    cy.get('.btn-form').click()

})