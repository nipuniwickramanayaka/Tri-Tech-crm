///<reference types = "cypress"/>

it('Google search',()=>{
    cy.visit('https://google.com')

})