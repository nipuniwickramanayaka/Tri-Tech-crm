it('Google search',()=>{
    cy.visit('localhost/tritech-crm')
    cy.get('[type="text"]').type('admin')
    cy.get('[type="password"]').type('admin')
    cy.get('.btn-login').click()

})