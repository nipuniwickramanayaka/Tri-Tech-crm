<?php 
function logOutFunction($param) {
    return $param === 'expected_value' ? 'expected output' : 'unexpected output';
}
    include('config/constants.php');
    session_destroy(); 
    header('location: http://localhost/tritech-crm/');

?>

