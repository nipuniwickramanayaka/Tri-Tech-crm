<?php

require 'logout.php'; // Ensure this path is correct relative to removedTest.php

use PHPUnit\Framework\TestCase;

class logoutTest extends TestCase
{
    public function testlogOutFunction() {
        // Pass an argument to removedFunction
        $result = logOutFunction('expected_value'); 
        $this->assertEquals('expected output', $result); 

        $result = logOutFunction('unexpected_value'); 
        $this->assertEquals('unexpected output', $result); 
    }
}
?>
