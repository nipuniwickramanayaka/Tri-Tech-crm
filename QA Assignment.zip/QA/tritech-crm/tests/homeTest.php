<?php

require 'home.php'; // Ensure this path is correct relative to removedTest.php

use PHPUnit\Framework\TestCase;

class homeTest extends TestCase
{
    public function testhomeFunction() {
        // Pass an argument to removedFunction
        $result = homeFunction('expected_value'); 
        $this->assertEquals('expected output', $result); 

        $result = homeFunction('unexpected_value'); 
        $this->assertEquals('unexpected output', $result); 
    }
}
?>
