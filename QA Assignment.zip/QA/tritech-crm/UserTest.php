<?php

use PHPUnit\Framework\TestCase;

class UserTest extends TestCase
{
    protected $adminBack;

    protected function setUp(): void
    {
        // Assuming adminback.php is autoloaded via Composer's autoloader
        $this->adminBack = new adminback();
    }

    public function testUserRegistration()
    {
        // Simulate user registration data
        $postData = [
            'username' => 'testuser',
            'email' => 'testuser@example.com',
            'password' => 'password123',
            'confirm_password' => 'password123'
        ];

        // Call the user registration method
        $result = $this->adminBack->user_register($postData);

        // Assert that registration was successful
        $this->assertTrue($result);
    }

    public function testUserLogin()
    {
        // Simulate user login data
        $postData = [
            'user_email' => 'testuser@example.com',
            'user_password' => 'password123'
        ];

        // Call the user login method
        $result = $this->adminBack->user_login($postData);

        // Assert that login was successful
        $this->assertContains('Login successful', $result);
    }
}