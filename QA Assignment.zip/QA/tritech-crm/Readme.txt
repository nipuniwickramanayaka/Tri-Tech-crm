How to run the TRI-TECH CRM  Project

1. Download the  zip file (Porject)

2. Extract the file and copy tritech-crm folder

3. Paste inside root directory(For xampp xampp/htdocs)

4. Start Apache and MySQL servers from XAMPP Control Panel.

5. Open PHPMyAdmin (http://localhost/phpmyadmin)

6. Create a database with name tritech-crm

7. Import tritech-crm.sql file (Given inside the SQL file folder in tritech-crm folder)

8. Run the script http://localhost/tritech-crm/ (Will be redirect to the login page)


Credential for Admin: (With Every Access)

Username: admin
Password: admin

Credential for User: (Limited Access)

Username: user
Password: user

