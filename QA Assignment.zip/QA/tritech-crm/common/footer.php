    <!-- Footer Start -->
    <div class="footer text-center">
        <div class="footer">
            <i class="fas fa-copyright"></i>
            <p>TriTech CRM 2022</p>
        </div>
    </div>
    <!-- Footer End -->
    </div>
</body>
</html> 